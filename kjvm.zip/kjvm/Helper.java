package System.Runtime.Native;

class Helper
{

}
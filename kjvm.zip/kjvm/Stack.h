#pragma once

class Stack
{
public:
	Stack(void);
public:
	virtual ~Stack(void);

};

public interface ITest4
{
	int div(int a, int b);
}
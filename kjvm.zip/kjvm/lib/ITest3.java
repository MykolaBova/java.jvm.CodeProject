public interface ITest3
{
	int mul(int a, int b);
}

public interface ITest
{
	int add(int a, int b);
}


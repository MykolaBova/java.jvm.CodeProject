public interface ITest2
{
	int Sub(int a, int b);
}
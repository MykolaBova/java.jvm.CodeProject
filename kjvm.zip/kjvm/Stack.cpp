#include "StdAfx.h"
#include "Stack.h"

Stack::Stack(void)
{
}

Stack::~Stack(void)
{
}
